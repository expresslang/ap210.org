ISO 10303-43
TC 184/SC 4

To access the ISO standard ISO 10303-43:2011-02(E) 
open the file "iso10303_43.htm".

The folders 
  "data"
  "images"
contain the various components of the main document.

To expand the document, unzip the file into an empty directory.
NOTE - if you already purchased other parts, then unzip the
file into the same directory as the other parts.
If asked when unzipping the file, you should overwrite any file in the images directory.



  

# Publishing Research Data with Jekyll Collections and Zenodo DOIs

This guide documents the workflow for preparing research datasets with Jekyll, publishing data to Zenodo, and integrating DOIs and badges into your research site.

---

## 1. Zipping Each Dataset Directory

Create and run this script to generate a ZIP for every dataset in `assets/research/`:

```bash
#!/bin/bash

set -e

ASSETS_DIR="assets/research"

for dir in "$ASSETS_DIR"/*/; do
  dname=$(basename "${dir%/}")
  zipfile="$ASSETS_DIR/${dname}.zip"
  echo "Zipping $dir to $zipfile"
  (cd "$ASSETS_DIR" && zip -r "${dname}.zip" "$dname" -x "${dname}.zip")
done

echo "All datasets zipped!"
```

```sh
chmod +x zip_research_assets.sh
./zip_research_assets.sh
```

**Screenshot:**  
_Add a screenshot here of your terminal after running the script (showing the files created)._  
![Terminal showing zip script output](screenshot_zip_script.png)

---

## 2. Uploading to Zenodo via Python Script

Use this Python script to automate uploading your ZIP file to Zenodo (sandbox for testing):

```python
import requests

ACCESS_TOKEN = 'YOUR_SANDBOX_TOKEN_HERE'
ZENODO_URL = "https://sandbox.zenodo.org/api/deposit/depositions"

headers = {"Content-Type": "application/json"}
params = {'access_token': ACCESS_TOKEN}

# Step 1: Create the deposition
r = requests.post(ZENODO_URL, params=params, json={}, headers=headers)
deposition_id = r.json()['id']

# Step 2: Upload the file
zip_filename = 'NIST_AP210_CFD_Project.zip'
files = {'file': open(f'assets/research/NIST_AP210_CFD_Project/{zip_filename}', 'rb')}
r = requests.post(f"{ZENODO_URL}/{deposition_id}/files", params=params, files=files)

# Step 3: Add metadata (edit as needed)
metadata = {
    'metadata': {
        'title': 'NIST AP210 CFD Project Data',
        'upload_type': 'dataset',
        'description': 'Data & scripts from the NIST AP210 CFD study.',
        'creators': [{'name': 'Thurman, Thomas R.'}],
    }
}
r = requests.put(f"{ZENODO_URL}/{deposition_id}", params=params, json=metadata, headers=headers)
print(f"Deposition metadata updated: {r.status_code}")

print("Go to your Zenodo sandbox to publish and get your DOI.")
```

**Screenshot:**  
_Add a screenshot of the Zenodo web UI showing your new upload, ready for publishing and with a DOI._  
![Zenodo upload and DOI](screenshot_zenodo_upload.png)

---

## 3. Reference DOI in Dataset Page (`_research/NIST_AP210_CFD_Project.md`)

Add the Zenodo DOI and link to your dataset page front matter:

```yaml
---
title: NIST_AP210_CFD_Project
layout: docs
summary: Data & scripts from the NIST AP210 CFD study.
zenodo_doi: 10.5281/zenodo.1234567
zenodo_link: https://doi.org/10.5281/zenodo.1234567
---
```

Include the badge in your Markdown body:

```markdown
# NIST AP210 CFD Project

**Associated publication:**  
[Representation of a Thermal Resistor Network Model of a Packaged Component in STEP AP210 Edition 2 (NISTIR 7648)](https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=903903)

**Download all project data from Zenodo:**  
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.1234567.svg)](https://doi.org/10.5281/zenodo.1234567)
```

**Screenshot:**  
_Add a screenshot of this dataset page in your browser, showing the badge and links._  
![Dataset detail page with Zenodo badge](screenshot_dataset_detail.png)

---

## 4. Show DOI/Badge on Collection Listing Page

Edit your research collection index page (e.g., `_pages/application/research/index.md`) to add this Liquid snippet:

```liquid
{% assign items = site.research | sort: "title" %}
{% for item in items %}
* [{{ item.title }}]({{ item.url | relative_url }}) – _{{ item.summary }}_
  {% if item.zenodo_doi %}
    • [![DOI](https://zenodo.org/badge/DOI/{{ item.zenodo_doi }}.svg)]({{ item.zenodo_link }})
  {% endif %}
{% endfor %}
```

**Screenshot:**  
_Add a screenshot of your site’s research listing page, showing one or more projects with the Zenodo badge link._  
![Research index page with Zenodo badges](screenshot_research_index.png)

---

## 5. Notes & Best Practices

- **Keep large ZIP files off GitHub**; host them on Zenodo for durability, citation, and versioning.
- **You can also include per-file links** or other supplementary documentation in your dataset pages.
- **Zenodo provides persistent DOIs**—cite them in publications for best practices in research reproducibility.

---

## 6. References

- [Zenodo REST API documentation](https://developers.zenodo.org/)
- [Jekyll Collections](https://jekyllrb.com/docs/collections/)

---

*Add your screenshots where shown to complete this guide for your group or documentation archive.*
